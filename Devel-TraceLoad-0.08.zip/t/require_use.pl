require 'strict.pm';
use strict;
__END__
require lib;
#use lib 't';
#use Data::Bar 1.0;
