package Data::Bar;
$Data::Bar::VERSION = '1.0';
1;
